#include<iostream>

using namespace std;

int main(){
    int finalResult=0;
    char playAgain;
    int playQuize(void);
    play:
    finalResult=playQuize();//finalrsult pe hmara data stire ho jaega
    cout<<"Your score is "<<finalResult<<endl;
    
    if (finalResult>=6){
        cout<<" **you are pass** "<<endl;
        cout<<"Do you want to play again the game y or n?"<<endl;
        cin>>playAgain;
        if(playAgain=='y'||playAgain=='Y'){
        goto play;
        }
        else{
            cout<<"Thnkyooooouuuu to playy the quizee....."<<endl;
        }
    }
    else{
        cout<<" you are fail "<<endl;
        cout<<"Do you want to play again the game y or n?"<<endl;
        cin>>playAgain;
        if(playAgain=='y'||playAgain=='Y'){
            playQuize();
        }
        else{
            cout<<"Thnkyooooouuuu to playy the quizee....."<<endl;
        }
    }
}
int playQuize()
{
    char c;//to select the s for start the game
    char option;
    int score=0;
    playInsideFunction:
    cout<<"--------WELCOME TO QUIZE GAME----------"<<endl;
    cout<<"----Please follow the given instructions------"<<endl;
    cout<<"step 1:Quize contain total 10 questions"<<endl;
    cout<<"step 2:You will give 1 marks for 1 right answer"<<endl;
    cout<<"step 3:There will no negative marking pattern."<<endl;
    cout<<"step 4:Please press s to start the game"<<endl;
    cout<<"step 5:Please select option a,b,c,d;"<<endl;
    cout<<"step 6:If score is >=6,you will pass the quiz"<<endl;
    cin>>c;
    if (c=='s'||c=='S'){
        cout<<"Q1.What is the launch date for Chandrayaan 3 mission?"<<endl;
        cout<<"(a)24 July 2023 (b)14 July 2023 (c)13 July 2023 (d)04 july 2023"<<endl;
        cin>>option;
        if(option=='a'||option=='A')
        {
            score =score+1;
            }
        else{
            score=score+0;
        }
        cout<<"Q2.Who is the prime minister of India?"<<endl;
        cout<<"(a) Narendra Modi (b) Aditynath (c) Kejriwal (d)Nitin"<<endl;
        cin>>option;
        if(option=='a'||option=='A')
        {
            score =score+1;
        }
        else{
            score=score+0;
        }
        cout<<"Q3. What is the national bird of India"<<endl;
        cout<<"(a) Peacock (b) Sparrow (c) Pigeon (d)Parrot"<<endl;
        cin>>option;
        if(option=='a' || option=='A'){
            score=score+1;
        }
        else{
            score=score+0;
        }
        cout<<"Q4. What is the national animal of India"<<endl;
        cout<<"(a) Tiger (b) Lion (c) Zebra (d)Leopard"<<endl;
        cin>>option;
        if(option=='a' || option=='A'){
            score=score+1;
        }
        else{
            score=score+0;
        }
        cout<<"Q5. What is the national flower of India"<<endl;
        cout<<"(a) Lotus (b) Rose (c) Lily (d)Sunflower"<<endl;
        cin>>option;
        if(option=='a' || option=='A'){
            score=score+1;
        }
        else{
            score=score+0;
        }
        cout<<"Q6. Who is the chief minister of UP"<<endl;
        cout<<"(a) Aditynath (b) Kejriwal (c) Nitin (d)Raghunath"<<endl;
        cin>>option;
        if(option=='a' || option=='A'){
            score=score+1;
        }
        else{
            score=score+0;
        }

        cout<<"Q7. What is the capital of UP"<<endl;
        cout<<"(a) Lukhnow (b) Praygraj (c) Mirzapur (d)Itawa"<<endl;
        cin>>option;
        if(option=='a' || option=='A'){
            score=score+1;
        }
        else{
            score=score+0;
        }

        cout<<"Q8. What is the capital of Jharkhand"<<endl;
        cout<<"(a) Ranchi (b) Ramgarh (c) Plamu (d)Dhanbad"<<endl;
        cin>>option;
        if(option=='a' || option=='A'){
            score=score+1;
        }
        else{
            score=score+0;
        }

        cout<<"Q9.Who is the leader of Congress"<<endl;
        cout<<"(a) Rahul (b) Sonia (c) Roshan (d)Rohit"<<endl;
        cin>>option;
        if(option=='a' || option=='A'){
            score=score+1;
        }
        else{
            score=score+0;
        }
        cout<<"Q10. Which one of the following state comes in North"<<endl;
        cout<<"(a) Delhi (b) Banglore (c) Chennai (d)Kerla"<<endl;
        cin>>option;
        if(option=='a' || option=='A'){
            score=score+1;
        }
        else{
            score=score+0;
        }

    }
        
    else{
        cout<<"you are enter wrong value,please enter s"<<endl;
        goto playInsideFunction;
    }
    
    return score;
}


